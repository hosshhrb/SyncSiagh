-- AlterTable
ALTER TABLE "SyncLog" ALTER COLUMN "entityMappingId" DROP NOT NULL;
